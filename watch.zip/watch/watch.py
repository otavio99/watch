#Import das bibliotecas do selenium que são uttilizados, o selenium
#é o nosso framework pra testes automatizados/web scapping
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

import time

import random as rd


def watch():

    #configuração do idiomado usado pelo navegador, forçando o selenium
    #a utilizar o navegador em inglês, afim de evitar problemas com o nome
    #dos elementos da página.
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {'intl.accept_languages': 'en_GB'})

    # options.add_argument('--headless')
    # options.add_argument('--no-sandbox')
    # options.add_argument('--disable-dev-shm-usage')

    #carrega e abre o chrome
    driver = webdriver.Chrome(chrome_options=options, executable_path='./chromedriver.exe')

    #carrega o site do google no driver que foi aberto
    first = 1
    try:
        while True:
            driver.get("https://www.youtube.com/watch?v=1e3H-oCF_xs")
            watch_time = rd.randrange(30, 180, 1)
            time.sleep(1)
            if first == 1 :
                driver.find_element_by_tag_name('body').send_keys(Keys.SPACE)
                first = first - 1
            time.sleep(watch_time)
    except:
        print("error")

#Inicia o servidor Flask
if __name__ == "__main__":
    watch()
